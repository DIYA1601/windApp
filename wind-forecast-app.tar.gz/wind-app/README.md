# UK wind forecast desk

Web app for a UK utility's day-ahead power buyers. It shows (1) the wind forecast that was actually
available when the day-ahead purchase had to be made, and (2) how accurate that forecast has been.
National wind only, Elexon BMRS data only (FUELHH actuals, WINDFOR forecasts), decisions made in January 2026.

**Live app:** `<ADD VERCEL/HEROKU URL HERE>`
**Demo video:** `<ADD UNLISTED YOUTUBE URL HERE>`

> **AI disclosure:** this project was built with assistance from Claude (Anthropic) for code generation,
> design and documentation. All logic was reviewed and tested by me.

## The key idea

WINDFOR holds many forecasts for each half-hour, each with a different `publishTime`. A buyer deciding on day D-1
may only use forecasts published up to a **cut-off**. For each delivery slot the app selects the latest forecast with
`publishTime <= cut-off(D-1)`, then compares it with the FUELHH outturn. Using the newest forecast would leak
information the buyer did not have.

## Assumptions (please read)

- **Cut-off: 09:00 UK local time on D-1** by default. This is an assumption, not a verified gate-closure time.
  It is editable in the UI and via the `DEFAULT_CUTOFF` env var.
- "Decisions made in January 2026" means decision days 1-31 Jan, so **delivery days are 2 Jan - 1 Feb 2026**.
- Error = forecast - actual (MW). Positive = forecast too high, so the buyer under-procures.
- MAPE ignores slots with actual < 100 MW (`MAPE_MIN_ACTUAL_MW`), where percentages explode.
- The uncertainty band for day D uses only errors from delivery days <= D-2 (D-1 is incomplete at decision time),
  and is hidden until at least 2 such days exist.
- Time handling: timestamps are UTC internally, day boundaries and the cut-off use Europe/London.
- The deployed app reads cached CSVs; it never calls Elexon at runtime.

## Repository layout

```
backend/
  app/
    config.py      settings, decision window, cut-off default
    elexon.py      Elexon stream API client (used only by ingest)
    data.py        CSV load/save (cached)
    decision.py    core logic: cut-off, forecast selection, decision table, uncertainty band
    metrics.py     MAE, RMSE, bias, MAPE, percentiles, by-hour, by-horizon, histogram
    main.py        FastAPI routes + serves the built UI
  scripts/ingest.py   fetch Elexon data -> backend/data/*.csv  (--synthetic for offline demo data)
  tests/test_core.py  leakage, cut-off, DST, metric maths, API smoke test
  data/               actuals.csv, forecasts.csv, meta.json  (committed)
frontend/
  src/App.jsx                 layout, controls
  src/components/DecisionView.jsx   forecast at cut-off vs actual, error band
  src/components/AccuracyView.jsx   metric cards and charts
  src/api.js, hooks.js, format.js, theme.js, styles.css
Dockerfile          multi-stage: build React, then Python image serving API + UI
docker-compose.yml  local run
heroku.yml          Heroku container deploy
.github/workflows/ci.yml  pytest + frontend build
docs/VIDEO_SCRIPTS.md
```

## API

`GET /api/config` · `/api/decision?day=YYYY-MM-DD&cutoff=HH:MM` · `/api/metrics` · `/api/metrics/daily` ·
`/api/metrics/by-hour` · `/api/metrics/by-horizon` · `/api/errors`. Interactive docs at `/docs`.

## Run it

### 1. Get the data (once)

```bash
cd backend
pip install -r requirements.txt
python -m scripts.ingest              # real Elexon data (needs internet), writes backend/data/*.csv
# python -m scripts.ingest --synthetic   # offline DEMO data only; the UI shows a warning banner
```

Check the Elexon request parameters in `app/elexon.py` against the live API docs if ingest returns an error.
Commit the generated files in `backend/data/` so the deployed app has data.

### 2. Docker (recommended)

```bash
docker compose up --build        # http://localhost:8000
```

### 3. Without Docker

```bash
cd backend && uvicorn app.main:app --reload --port 8000
cd frontend && npm install && npm run dev      # http://localhost:5173 (proxies /api to :8000)
```

### Tests

```bash
cd backend && python -m pytest -q
```

## Deploy (Heroku, container stack)

```bash
heroku create <app-name>
heroku stack:set container
git push heroku main
```

The image reads `$PORT`, serves the API under `/api` and the React app at `/`.
(Vercel is not used: it would need the API reworked as serverless functions, and a single container is simpler.)

## Development practices

Core logic is pure pandas functions separated from the web layer; tests pin the no-leakage rule and sign convention;
config in one module; CI runs tests and the production build; data is cached and versioned so deploys are reproducible.
